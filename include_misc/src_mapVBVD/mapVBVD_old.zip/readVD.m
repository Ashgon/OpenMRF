function data = readVD(filename,varargin)

%  Reads Siemens Avanto .dat raw data from VB13, VB15 and VB17
%  Data file contains an header and a data block.
%  Raw data is oversampled!
%
%  REQUIRES: readVB17Header.m
%
%  Philipp Ehses 11.02.07, updated for VB15 1.April 09
%  Daniel Weber  27.08.09, updated for VB17
%  Philipp Ehses 04.09.09, added direct averaging mode
%  Philipp Ehses 10.01.10, added fastRead + progress output
%  Felix Breuer  31.03.11, added support for noise & ref scans
%
% Output:
%
% rawdata:      raw data as read in
% header:       header information (TRs, TEs,...)
% noise:        noise prescans
% phasecor:     phase correction scans
% RTfeedback:   realtime feedback data
%
%
% Zurueckgegebene Dimensionen in rawdata:
%
%  1) Columns
%  2) Lines
%  3) Partitions
%  4) Channels/No. of Coils
%  5) Slices
%  6) Contrasts/Echoes
%  7) (Cardiac-) Phases
%  8) Sets
%  9) Averages
% 10) Messungen
% 11) Ida
% 12) Idb
% 13) Idc
% 14) Idd
% 15) Ide
%
%
% Input parameters:
%      
% filename:      Entweder kompletter Dateiname mit Pfad, oder nur eine Nummer, die dann f???r meas_MIDxxxx_*.dat steht
% 
% sqz:           Dampft alle ueberfluessigen Dimensionen ein fuer die Rueckgabe
% avg:           Mittelt ueber die  9. Dimension, und zwar schon beim Einlesen (spart Speicher)
% avgmeas:       Mittelt ueber die 10. Dimension, und zwar schon beim Einlesen (spart Speicher)
% undoOSr:       Entfernt das Oversampling in Readrichtung
% singlePrec:    Gibt die Daten als Single zurueck, ansonsten als Double
% pca:           Fuehrt in Spulenrichtung eine Singular Value Decomposition durch
% sortCoils:     Sortiert die Daten in Spulenrichtung nach Intensitaet 
%
%


%%%%% Alle optionalen Parameter werden als Variablen definiert %%%%%
    for arg=1:size(varargin,2)
        if ischar(varargin{arg})    % Falls das Argument ein String ist...
            eval(['arg_', varargin{arg}, ' = ', '1', ';']);  % ... wird ihm erst mal der Wert 1 zugewiesen.
        elseif isnumeric(varargin{arg}) % Falls es aber eine Zahl ist...
            if arg >=1  % ... und das Argument nicht das erste ist...
                if varargin{arg-1}  % ... und das vorige Argument ein String war...
                    % ... dann wird der Wert des aktuellen Arguments dem letzten Argument zugewiesen
                    eval(['arg_', varargin{arg-1}, ' = ', num2str(varargin{arg}), ';']); 
                end
            end
        end
    end
    clear varargin arg
    
    % Parameter definieren, die nicht uebergeben wurden aber definiert sein sollten:
    if ~exist('arg_sqz','var');         arg_sqz             = 0;    end  % squuezes output
    if ~exist('arg_avg','var');         arg_avg             = 0;    end  % enables direct averaging mode (data is directly summed up to save memory)
    if ~exist('arg_avgmeas','var');     arg_avgmeas         = 0;    end  
    if ~exist('arg_undoOSr','var');     arg_undoOSr         = 0;    end  % removes oversampling in the read-out direction
    if ~exist('arg_refScanOnly','var'); arg_refScanOnly     = 0;    end  % extracts only the reference scan
    if ~exist('arg_imaScanOnly','var'); arg_imaScanOnly     = 1;    end  % extracts only the imaging scan
    if ~exist('arg_refScanFull','var'); arg_refScanFull     = 0;    end  % in the case of integrated ACS                                                                
    if ~exist('arg_exclACS','var');     arg_exclACS         = 0;    end  % removes ACS data from the imaging data (IPAT Data often comes with integrated ACS data)                                                              
    if ~exist('arg_ignSeg','var');      arg_ignSeg          = 0;    end  % ignore segments in TSE and EPI
    if ~exist('arg_filter','var');      arg_filter          = 0;    end  % applies tukey filter to the data in all spatial dimensions in order to avoid Gibbs ringing
    if ~exist('arg_center','var');      arg_center          = 0;    end  % in the case of asymmetric echo or partial Fourier Acquisition for image data only
    
    
    arg.sqz         = arg_sqz;
    arg.avg         = arg_avg;
    arg.avgmeas     = arg_avgmeas;
    arg.undoOSr     = arg_undoOSr;
    arg.refScanOnly = arg_refScanOnly;
    arg.imaScanOnly = arg_imaScanOnly;
    arg.refScanFull = arg_refScanFull;
    arg.exclACS     = arg_exclACS;
    arg.ignSeg      = arg_ignSeg;
    arg.filter      = arg_filter;
    arg.center      = arg_center;
    
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Option, die MeasNumber statt des Dateinamens zu uebergeben:
    if ischar(filename)
        if  ~strcmpi(filename(end-3:end),'.dat');
            filename=[filename '.dat'];   %% adds filetype ending to file
        end
    else % filename not a string, so assume that it is the MeasNumber (shortcut, instead of Avanto_fullfile)
        
        num = filename;
               
        
        try
%             filename = ls(['meas_MID' num2str(num) '_*.dat'])
            filename = ls(['meas_MID*' num2str(num) '_*FID*.dat'])% tbenkert: modification to ignore zeros in front of real MID number
        catch ME
            filename = ls(['meas_MID' sprintf('%05d',num) '_*.dat'])
        end
        
        
        if isunix
            str = strfind(filename,'.dat');
            filename=[filename(1:str-1) '.dat']; % crops line break
        end
    end
    
    
    
    tic;
    fid = fopen(filename,'r','l','US-ASCII'); % US-ASCII necessary for UNIX based systems
    fseek(fid,0,'eof');
    fileSize = ftell(fid);
    
    fseek(fid,4,'bof');
    NMeas = fread(fid,1,'uint32'); % number of measurements in file, only one supported for now
    fseek(fid,16,'bof');
    % measOffset: points to beginning of header, usually at 10240 bytes
    measOffset = fread(fid,1,'uint64');
    measLength = fread(fid,1,'uint64');
    fseek(fid,measOffset,'bof');
    hdrLength = fread(fid,1,'uint32');
    
    datStart  = measOffset + hdrLength;
    
    % reads protocol header information
    [header headerascii] = readVD11Header(fid);
    
    phasestab = [];
    
    if arg_undoOSr
        % VB13 hat kein Meas, dafuer hat VB17 kein header.MeasYaps.flReadoutOSFactor ...
        if ~isfield(header,'MeasYaps')
            flReadoutOSFactor = 2;
        else
            if isfield(header.MeasYaps, 'flReadoutOSFactor')
                flReadoutOSFactor=header.MeasYaps.flReadoutOSFactor;     % VB13
            else
                flReadoutOSFactor=header.Meas.flReadoutOSFactor;         % VB17
            end
        end
    end
        
    
    
     if isfield(header.Config,'RefScanMode')
         RefScanMode = header.Config.RefScanMode;
     else
         RefScanMode = 0;
     end
 
 
    
    NLines      = max(header.Config.NLinMeas,1); 
    NPart       = max(header.Config.NParMeas,1);   
    NSli        = max(header.Config.NSlcMeas,1); 
    NAve        = max(header.Config.NAveMeas,1); 
    NEco        = max(header.Config.NEcoMeas,1); 
    NPhs        = max(header.Config.NPhsMeas,1); 
    NSeg        = max(header.Config.NSegMeas,1); 
    NMeas       = max(header.Config.NRepMeas,1); 
    NSet        = max(header.Config.NSetMeas,1); 
    NIda        = max(header.Config.NIdaMeas,1); 
    NIdb        = max(header.Config.NIdbMeas,1); 
    NIdc        = max(header.Config.NIdcMeas,1); 
    NIdd        = max(header.Config.NIddMeas,1); 
    NIde        = max(header.Config.NIdeMeas,1); 
    
    % some dimensions are reduced during readout in case 
    % a corresponding argument is set to true    
    % number of averages to be allocated:
    NAveAlloc     = NAve;
    if arg_avg
        NAveAlloc = 1;
    end
    % number of measurements to be allocated:
    NMeasAlloc     = NMeas;
    if arg_avgmeas
        NMeasAlloc = 1;
    end
    % number of segments to be allocated:
    NSegAlloc = NSeg;
    
    if arg_ignSeg
        NSegAlloc = 1;
    end
    
    
    % data will be read in two steps (and two while loops):
    %   1) reading all MDHs to find maximum line no., partition no.,... for
    %      ima, ref,... scan
    %   2) reading the data
    
    %%% start at beginning of first line
    cPos = datStart;
    
    tic;
    mask.MDH_ACQEND = 0;

    while ~mask.MDH_ACQEND
        
        %%%% INLINING TO SPEED UP THE CODE %%%%
        
        % inlining of readScanHeader
        fseek(fid,cPos+40,'bof');
        scanHeader.aulEvalInfoMask            = fread(fid,  [1 2], 'uint32');
        dummy                                 = fread(fid,      2, 'uint16');
        scanHeader.ushSamplesInScan           = dummy(1);
        scanHeader.ushUsedChannels            = dummy(2);
        scanHeader.sLC                        = fread(fid, [1 14], 'ushort');  
        fseek(fid,cPos+84,'bof');
        dummy                                 = fread(fid,      8, 'uint16');
        scanHeader.ushKSpaceCentreColumn      = dummy(1);
        scanHeader.ushKSpaceCentreLineNo      = dummy(7);
        scanHeader.ushKSpaceCentrePartitionNo = dummy(8);
        cPos = cPos + 192; % scanHeader = 192 byte
        
        
        % inlining of evalInfoMask
        mask.MDH_ACQEND             = min(bitand(scanHeader.aulEvalInfoMask(1), 2^0),1);
        mask.MDH_RTFEEDBACK         = min(bitand(scanHeader.aulEvalInfoMask(1), 2^1),1);
        mask.MDH_HPFEEDBACK         = min(bitand(scanHeader.aulEvalInfoMask(1), 2^2),1);
        mask.MDH_REFPHASESTABSCAN   = min(bitand(scanHeader.aulEvalInfoMask(1), 2^14),1);
        mask.MDH_PHASESTABSCAN      = min(bitand(scanHeader.aulEvalInfoMask(1), 2^15),1);
        mask.MDH_PHASCOR            = min(bitand(scanHeader.aulEvalInfoMask(1), 2^21),1);
        mask.MDH_PATREFSCAN         = min(bitand(scanHeader.aulEvalInfoMask(1), 2^22),1);
        mask.MDH_PATREFANDIMASCAN   = min(bitand(scanHeader.aulEvalInfoMask(1), 2^23),1);
        mask.MDH_NOISEADJSCAN       = min(bitand(scanHeader.aulEvalInfoMask(1), 2^25),1);
        mask.MDH_IMASCAN            = 1;
        
       
        if (mask.MDH_ACQEND || mask.MDH_RTFEEDBACK || mask.MDH_HPFEEDBACK || mask.MDH_REFPHASESTABSCAN || mask.MDH_PHASESTABSCAN || mask.MDH_PHASCOR || mask.MDH_NOISEADJSCAN)
            mask.MDH_IMASCAN = 0; 
        end     
        
        
        %%%% END OF INLINING %%%%      
        
        
        if mask.MDH_ACQEND
            break;
        end
        
        % Get informatio from NoiseScan
        if (mask.MDH_NOISEADJSCAN)
            if ~isfield(header,'NoiseScan'),
                header.NoiseScan.NCol = scanHeader.ushSamplesInScan;
%                 if arg_undoOSr
%                     header.NoiseScan.NCol = ceil(scanHeader.ushSamplesInScan/flReadoutOSFactor);
%                 end
                header.NoiseScan.NCha   = scanHeader.ushUsedChannels;
                header.NoiseScan.FidPos = cPos;
                header.NoiseScan.NCnt   = 1;
             
            else
              
                header.NoiseScan.NCnt   = header.NoiseScan.NCnt + 1;
            end
        end

        % Get informatio about RT Feedback Scan
        if (mask.MDH_RTFEEDBACK)
            if ~isfield(header,'RTFScan'),
                header.RTFScan.NCol   = scanHeader.ushSamplesInScan;
                header.RTFScan.NCha   = scanHeader.ushUsedChannels;
                header.RTFScan.FidPos = cPos;
                header.RTFScan.NCnt   = 1;
            else
                header.RFTScan.NCnt = header.RTFScan.NCnt + 1;
            end

        end

        % Get informatio about HP Feedback Scan
        if (mask.MDH_HPFEEDBACK)
            if ~isfield(header,'HPFScan'),
                header.HPFScan.NCol   = scanHeader.ushSamplesInScan;
                header.HPFScan.NCha   = scanHeader.ushUsedChannels;
                header.HPFScan.FidPos = cPos;
                header.HPFScan.NCnt   = 1;
            else
                header.HPFScan.NCnt = header.HPFScan.NCnt + 1;
            end

        end

        % Get informatio about Phase Correction Scan
        if (mask.MDH_PHASCOR)
            if ~isfield(header,'PhasCorScan'),
                header.PhasCorScan.NCol   = scanHeader.ushSamplesInScan;
                header.PhasCorScan.NCha   = scanHeader.ushUsedChannels;
                header.PhasCorScan.FidPos = cPos;
                header.PhasCorScan.NCnt   = 1;
                header.PhasCorScan.CenterCol    = scanHeader.ushKSpaceCentreColumn;
                header.PhasCorScan.CenterLine   = scanHeader.ushKSpaceCentreLineNo;
                header.PhasCorScan.CenterPart   = scanHeader.ushKSpaceCentrePartitionNo;
                
            else
                header.PhasCorScan.NCnt = header.PhasCorScan.NCnt + 1;
            end
        end

        % Get informatio about Rephase Stab Scan
        if (mask.MDH_REFPHASESTABSCAN)
            if ~isfield(header,'RePhasStabScan'),
                header.RePhasStapScan.NCol   = scanHeader.ushSamplesInScan;
                header.RePhasStapScan.NCha   = scanHeader.ushUsedChannels;
                header.RePhasStapScan.FidPos = cPos;
                header.RePhasStabScan.NCnt   = 1;
            else
                header.RePhasStabScan.NCnt = header.RePhasStabScan.NCnt + 1;
            end
        end

        % Get informatio about Phase Stab Scan
        if (mask.MDH_PHASESTABSCAN)
            if ~isfield(header,'PhStabScan'),
                header.PhStapScan.NCol   = scanHeader.ushSamplesInScan;
                header.PhStapScan.NCha   = scanHeader.ushUsedChannels;
                header.PhStapScan.FidPos = cPos;
                header.PhStabScan.NCnt   = 1;
            else
                header.PhStabScan.NCnt = header.PhStabScan.NCnt + 1;
            end
        end        
        
        % Get informatio about PAT Reference Scan   
        if (mask.MDH_PATREFSCAN || mask.MDH_PATREFANDIMASCAN)
            if ~isfield(header,'RefScan')
                header.RefScan.NCol = scanHeader.ushSamplesInScan;
                header.RefScan.NCha = scanHeader.ushUsedChannels;

                header.RefScan.FidStart = cPos;
                header.RefScan.FidEnd   = cPos;
                header.RefScan.NCnt     = 1;

                header.RefScan.CenterCol    = scanHeader.ushKSpaceCentreColumn;
                header.RefScan.CenterLine   = scanHeader.ushKSpaceCentreLineNo;
                header.RefScan.CenterPart   = scanHeader.ushKSpaceCentrePartitionNo;

                header.RefScan.MinLine = scanHeader.sLC(1) + 1;
                header.RefScan.MaxLine = scanHeader.sLC(1) + 1;
                header.RefScan.MinPart = scanHeader.sLC(4) + 1;
                header.RefScan.MaxPart = scanHeader.sLC(4) + 1;
            else
                header.RefScan.NCnt = header.RefScan.NCnt + 1;
                header.RefScan.FidEnd = cPos;

                header.RefScan.MinLine  = min(scanHeader.sLC(1) + 1, header.RefScan.MinLine);
                header.RefScan.MaxLine  = max(scanHeader.sLC(1) + 1, header.RefScan.MaxLine);

                header.RefScan.MinPart  = min(scanHeader.sLC(4) + 1, header.RefScan.MinPart);
                header.RefScan.MaxPart  = max(scanHeader.sLC(4) + 1, header.RefScan.MaxPart);
            end
        end

        % Get informatio about the actual imaging scan
         
        if (mask.MDH_IMASCAN)
            if ~(mask.MDH_PATREFSCAN && RefScanMode == 4)               
                if ~isfield(header,'ImaScan'),
                    header.ImaScan.NCol         = scanHeader.ushSamplesInScan;              
                    header.ImaScan.NCha         = scanHeader.ushUsedChannels;
                    

                    header.ImaScan.FidStart     = cPos;
                    header.ImaScan.FidEnd       = cPos;
                    header.ImaScan.NCnt         = 1;

                    header.ImaScan.CenterCol    = scanHeader.ushKSpaceCentreColumn + 1;
                    header.ImaScan.CenterLine   = scanHeader.ushKSpaceCentreLineNo + 1;
                    header.ImaScan.CenterPart   = scanHeader.ushKSpaceCentrePartitionNo +1;

                    header.ImaScan.MinCol  = 1;
                    header.ImaScan.MaxCol  = header.ImaScan.NCol;
                    
                    header.ImaScan.MinLine = scanHeader.sLC(1) + 1;
                    header.ImaScan.MaxLine = scanHeader.sLC(1) + 1;
                    
                    header.ImaScan.MinPart = scanHeader.sLC(4) + 1;
                    header.ImaScan.MaxPart = scanHeader.sLC(4) + 1;
                else
                    header.ImaScan.NCnt     = header.ImaScan.NCnt + 1;
                    header.ImaScan.FidEnd   = cPos;

                    header.ImaScan.MinLine  = min(scanHeader.sLC(1) + 1, header.ImaScan.MinLine);
                    header.ImaScan.MaxLine  = max(scanHeader.sLC(1) + 1, header.ImaScan.MaxLine);

                    header.ImaScan.MinPart  = min(scanHeader.sLC(4) + 1, header.ImaScan.MinPart);
                    header.ImaScan.MaxPart  = max(scanHeader.sLC(4) + 1, header.ImaScan.MaxPart);
                end
            end
        end
        
        
        % jump to next mdh (mdhs for coils 2..n are skipped)
        nCompFloat = scanHeader.ushUsedChannels*scanHeader.ushSamplesInScan + scanHeader.ushUsedChannels*4; % channelHeader = 32 byte = 8 'float'
                
        cPos = cPos + 2*nCompFloat*4;

    end % while

    
    
    
    % PF_HALF = 0x01, PF_5_8  = 0x02, PF_6_8  = 0x04, PF_7_8  = 0x08, PF_OFF  = 0x16,
    pf = [ 4/8 5/8 6/8 7/8  1 ];
    log2(header.Meas.ucPhasePartialFourier)
    
%     if isfield(header,'ImaScan')
%         header.ImaScan.PhasePartialFourier = pf(log2(header.Meas.ucPhasePartialFourier)+1);
%         header.ImaScan.SlicePartialFourier = pf(log2(header.Meas.ucSlicePartialFourier)+1);        
%         %header.ImaScan
%     end
%     
    
    NoiseData   = [];
    RefData     = [];
    ImaData     = [];
    PcData      = [];
    RTfeedback  = [];
    
  
    if isfield(header.Config,'RefScanMode')    
    %if isfield(header,'RefScan')
        
        RefScanMode = header.Config.RefScanMode;
        %  // SEQ::PAT_REF_SCAN_UNDEFINED  
        %  // SEQ::PAT_REF_SCAN_INPLACE   (2)                
        %  // SEQ::PAT_REF_SCAN_EXTRA     (3)
        %  // SEQ::PAT_REF_SCAN_PRESCAN   (4)

        if arg_refScanFull && RefScanMode == 2 || RefScanMode == 1;
            NRefLines = NLines;
            NRefPart  = NPart;
        else
            NRefLines = header.Config.NRefLin;
            NRefPart  = header.Config.NRefPar;
        end

        if arg_refScanFull
            FirstRefLine = 1;
            FirstRefPart = 1;
        else
            FirstRefLine = header.RefScan.MinLine; % Not yet checked if floor or ceil
            FirstRefPart = header.RefScan.MinPart;
        end
    else
        RefScanMode = 0;
    end

    %%%%%% Allocate Memory %%%%%%%

    
    % fxbreuer: wip
    if isfield(header,'PhasCorScan')
       
              
        NPcCha = header.PhasCorScan.NCha;
        NPcCnt = header.PhasCorScan.NCnt;
        
        if arg_undoOSr
            header.PhasCorScan.NCol = ceil(header.PhasCorScan.NCol/flReadoutOSFactor);
        end 
        
        header.PhasCorScan
        NPcCol = header.PhasCorScan.NCol;
        
        NPcAve      = 2; % for EPI Scan 
        NPcLines    = 1; % Usually only the center line is acquired
        NPcPart     = 1; % Usually only the center partition is acquired

        PcSize = [NPcCol NPcCha NPcLines NPcPart NSli NEco NPhs NSeg NSet NPcAve NMeas NIda NIdb NIdc NIdd NIde];
        
        
        try
            PcData = zeros(PcSize(1)*PcSize(2),prod(PcSize(3:end)),'single');
            PcData(1) = 1e-31 * 1i;
        catch exception
            error('*** Error allocating memory for Phase Cor Scan - aborting');
        end
    end
    
    
    if isfield(header,'NoiseScan')
        
        NNoiseCha = header.NoiseScan.NCha;
        NNoiseCnt = header.NoiseScan.NCnt;
        
%         if arg_undoOSr
%             header.NoiseScan.NCol = ceil(header.NoiseScan.NCol/flReadoutOSFactor);
%         end

        NNoiseCol = header.NoiseScan.NCol;


        NoiseSize = [NNoiseCol NNoiseCha NNoiseCnt];

        try
            NoiseData = zeros(NoiseSize(1)*NoiseSize(2),NoiseSize(3),'single'); 
        catch exception
            error('*** Error allocating memory for Noise Scan - aborting');
        end
    end

    
    if isfield(header,'RefScan') && ~arg_imaScanOnly
        if arg_undoOSr
            header.RefScan.NCol         = ceil(header.RefScan.NCol/flReadoutOSFactor);
            header.RefScan.CenterCol    = ceil(header.RefScan.CenterCol/flReadoutOSFactor);
        end

        if arg_refScanFull
            NRefCol = header.RefScan.NCol;
        else
            NRefCol = 2 * header.RefScan.CenterCol;
        end
        
        NRefCha = header.RefScan.NCha;

        RefSize = [NRefCol NRefCha NRefLines NRefPart NSli NEco NPhs NSegAlloc NSet NAveAlloc NMeasAlloc NIda NIdb NIdc NIdd NIde];

        try 
            RefData  = zeros(RefSize(1)*RefSize(2),prod(RefSize(3:end)),'single');
            % stupid matlab (why?, see further below)
            RefData(1) = 1e-31 * 1i;
        catch
            disp('*** Error allocating memory for Reference Scan - aborting')
            return  
        end
    end
    

    
    if isfield(header,'ImaScan') && ~arg_refScanOnly
        
        NImaCha = header.ImaScan.NCha;
        
        header.ImaScan.NLine = NLines;
        header.ImaScan.NPart = NPart;
        
        if arg_undoOSr
            header.ImaScan.NCol         = ceil(header.ImaScan.NCol/flReadoutOSFactor);
            header.ImaScan.CenterCol    = ceil(header.ImaScan.CenterCol/flReadoutOSFactor);
            header.ImaScan.MaxCol       = ceil(header.ImaScan.MaxCol/flReadoutOSFactor);
            header.ImaScan.MinCol       = ceil(header.ImaScan.MinCol/flReadoutOSFactor);
        end
                
        % put k-spce center in the center of the matrix (hope the indexing
        % is right); by fxbreuer 
        
        if arg_center
            
            header.ImaScan.NCol      = 2 * (header.ImaScan.MaxCol - (header.ImaScan.CenterCol - 1));
            header.ImaScan.MinCol    = header.ImaScan.NCol - (header.ImaScan.MaxCol - (header.ImaScan.MinCol-1)) + 1;
            header.ImaScan.MaxCol    = header.ImaScan.NCol;
            header.ImaScan.CenterCol = header.ImaScan.NCol/2 + 1;
                   
            
            if header.ImaScan.MaxLine > header.ImaScan.MinLine 
                header.ImaScan.NLine        =  2 * max(header.ImaScan.MaxLine - (header.ImaScan.CenterLine-1) ,header.ImaScan.CenterLine - header.ImaScan.MinLine);
                header.ImaScan.MinLine      = header.ImaScan.NLine/2+1 - (header.ImaScan.CenterLine - header.ImaScan.MinLine);
                header.ImaScan.MaxLine      = header.ImaScan.NLine/2+1 + (header.ImaScan.MaxLine - header.ImaScan.CenterLine);
                header.ImaScan.CenterLine   = header.ImaScan.NLine/2+1 
            end
            
            if header.ImaScan.MaxPart > header.ImaScan.MinPart 
                header.ImaScan.NPart        =  2 * max(header.ImaScan.MaxPart - (header.ImaScan.CenterPart-1) ,header.ImaScan.CenterPart - header.ImaScan.MinPart);
                header.ImaScan.MinPart      = header.ImaScan.NPart/2+1 - (header.ImaScan.CenterPart - header.ImaScan.MinPart);
                header.ImaScan.MaxPart      = header.ImaScan.NPart/2+1 + (header.ImaScan.MaxPart - header.ImaScan.CenterPart);
                header.ImaScan.CenterPart   = header.ImaScan.NPart/2+1 
            end                          
                       
        end
        
        
        
        ImaMaxCol   = header.ImaScan.MaxCol;
        ImaMinCol   = header.ImaScan.MinCol;
        
        ImaMaxLine  = header.ImaScan.MaxLine;
        ImaMinLine  = header.ImaScan.MinLine;
        
        ImaMaxPart  = header.ImaScan.MaxPart;
        ImaMinPart  = header.ImaScan.MinPart;
                        
        NImaCol     = header.ImaScan.NCol;
        NImaLines   = header.ImaScan.NLine;
        NImaPart    = header.ImaScan.NPart;
                
        
        ImaSize = [NImaCol NImaCha NImaLines NImaPart NSli NEco NPhs NSegAlloc NSet NAveAlloc NMeasAlloc NIda NIdb NIdc NIdd NIde];
        
      
        
        try
            ImaData  = zeros(ImaSize(1)*ImaSize(2),prod(ImaSize(3:end)),'single');
           
            % stupid matlab has issues with complex arrays:
            % if first value in array has imaginary part everything is fine - 
            % otherwise filling an array in arbitrary order becomes painfully slow
            ImaData(1) = 1e-31 * 1i;
        catch
            disp('*** Error allocating memory for image only scan - aborting')
            return  
        end    
    end
    
 
    
    %%%% end allocate memory
        
    disp(['Searched through MDHs and allocated memory in ' num2str(toc) ' s.']);

    %%% start at beginning of first line
    cPos = datStart;                  

    mask.MDH_ACQEND = 0;
    percentFinished = 0;
    cNoiseIndex     = 0;
   
    
    cPos = datStart;
    
    tic;
    mask.MDH_ACQEND = 0;

        
    while ~mask.MDH_ACQEND
        
        %%%% INLINING TO SPEED UP THE CODE %%%%
        
        % inlining of readScanHeader
        fseek(fid,cPos+40,'bof');
        scanHeader.aulEvalInfoMask            = fread(fid,  [1 2], 'uint32');
        dummy                                 = fread(fid,      2, 'uint16');
        scanHeader.ushSamplesInScan           = dummy(1);
        scanHeader.ushUsedChannels            = dummy(2);
        scanHeader.sLC                        = fread(fid, [1 14], 'ushort');  
        fseek(fid,cPos+84,'bof');
        dummy                                 = fread(fid,      8, 'uint16');
        scanHeader.ushKSpaceCentreColumn      = dummy(1);
        scanHeader.ushKSpaceCentreLineNo      = dummy(7);
        scanHeader.ushKSpaceCentrePartitionNo = dummy(8);
        cPos = cPos + 192; % scanHeader = 192 byte
        
        
        % inlining of evalInfoMask
        mask.MDH_ACQEND             = min(bitand(scanHeader.aulEvalInfoMask(1), 2^0),1);
        mask.MDH_RTFEEDBACK         = min(bitand(scanHeader.aulEvalInfoMask(1), 2^1),1);
        mask.MDH_HPFEEDBACK         = min(bitand(scanHeader.aulEvalInfoMask(1), 2^2),1);
        mask.MDH_REFPHASESTABSCAN   = min(bitand(scanHeader.aulEvalInfoMask(1), 2^14),1);
        mask.MDH_PHASESTABSCAN      = min(bitand(scanHeader.aulEvalInfoMask(1), 2^15),1);
        mask.MDH_PHASCOR            = min(bitand(scanHeader.aulEvalInfoMask(1), 2^21),1);
        mask.MDH_PATREFSCAN         = min(bitand(scanHeader.aulEvalInfoMask(1), 2^22),1);
        mask.MDH_PATREFANDIMASCAN   = min(bitand(scanHeader.aulEvalInfoMask(1), 2^23),1);
        mask.MDH_NOISEADJSCAN       = min(bitand(scanHeader.aulEvalInfoMask(1), 2^25),1);
        mask.MDH_REFLECT            = min(bitand(scanHeader.aulEvalInfoMask(1), 2^24),1);
        mask.MDH_SIGNREV            = min(bitand(scanHeader.aulEvalInfoMask(1), 2^17),1);
        
        
        mask.MDH_IMASCAN            = 1;
        if (mask.MDH_ACQEND || mask.MDH_RTFEEDBACK || mask.MDH_HPFEEDBACK || mask.MDH_REFPHASESTABSCAN || mask.MDH_PHASESTABSCAN || mask.MDH_PHASCOR || mask.MDH_NOISEADJSCAN)
            mask.MDH_IMASCAN = 0; 
        end  

        fseek(fid,cPos,'bof');
        
        cLine      = scanHeader.sLC(1)  + 1;         %%% current line
        cAve       = scanHeader.sLC(2)  + 1;         %%% current scan ('average')
        cSli       = scanHeader.sLC(3)  + 1;         %%% current slice
        cPart      = scanHeader.sLC(4)  + 1;         %%% current partition  
        cPhs       = scanHeader.sLC(6)  + 1;         %%% current phase cycling step
        cEco       = scanHeader.sLC(5)  + 1;         %%% current echo no (untested)
        cMeas      = scanHeader.sLC(7)  + 1;         %%% current measurement no
        cSet       = scanHeader.sLC(8)  + 1;         %%% current set no
        cSeg       = scanHeader.sLC(9)  + 1;         %%% current segment for future use
        cIda       = scanHeader.sLC(10) + 1;         %%% ICE dim a
        cIdb       = scanHeader.sLC(11) + 1;         %%% ICE dim b
        cIdc       = scanHeader.sLC(12) + 1;         %%% ICE dim c
        cIdd       = scanHeader.sLC(13) + 1;         %%% ICE dim d
        cIde       = scanHeader.sLC(14) + 1;         %%% ICE dim e
%         cCha       = chaHeader.ulChannelId + 1;    %%% current channel
        

        
        %%%% END OF INLINING %%%%      
        
        if mask.MDH_ACQEND
            break;
        end

        % jump to next mdh (mdhs for coils 2..n are skipped)
        nCompFloat = scanHeader.ushUsedChannels*scanHeader.ushSamplesInScan + scanHeader.ushUsedChannels*4; % channelHeader = 32 byte = 8 'float'
        
        a = fread(fid, [2 nCompFloat], 'float');
        
        cPos = cPos + 2*nCompFloat*4;
 
    
        temp    = reshape(single((a(1,:) + 1j.*a(2,:))),[scanHeader.ushSamplesInScan + 4, scanHeader.ushUsedChannels]);
        temp    = temp(4+1:scanHeader.ushSamplesInScan+4,:);
        
        
        if mask.MDH_REFLECT
            temp = temp(end:-1:1,:);
        end
            
        if mask.MDH_SIGNREV
            temp = -temp;
        end

        % remove OS
        if arg_undoOSr  && ~mask.MDH_NOISEADJSCAN
            fprintf('Removing oversampling ... \n');
            ltemp = size(temp,1);
            temp  = fftshift(ifft(fftshift(temp,1),[],1),1);
            temp  = fftshift(fft(fftshift(temp(ltemp*(1-1/flReadoutOSFactor)/2 + 1:ltemp*(1+1/flReadoutOSFactor)/2,:),1),[],1),1);
        end
        
        % Read Noise,Phasestab and feedback Scans
        
        if (mask.MDH_NOISEADJSCAN)   
            cNoiseIndex = cNoiseIndex + 1;
            tempNoise   = temp(1:NNoiseCol,:);
   
            NoiseData(:,cNoiseIndex) = tempNoise(:);
                                    
%         elseif (mask.MDH_RTFEEDBACK || mask.MDH_HPFEEDBACK) % not pre-allocated yet
%             RTfeedback = [RTfeedback temp.'];
%         elseif (mask.MDH_PHASESTABSCAN || mask.MDH_REFPHASESTABSCAN) % not pre-allocated yet   
%             phasestab  = [phasestab temp.'];
        end

        
        % Read Phase Coorection Scan
        
        if (mask.MDH_PHASCOR)
                          
            cPcIndex = 1 + (cLine -  1 - header.PhasCorScan.CenterLine + NPcLines * ( cPart - 1 - header.PhasCorScan.CenterPart + NPcPart * (cSli-1 + NSli * (cEco-1 +...
                        NEco * (cPhs-1 + NPhs * (cSeg-1 + NSeg * (cSet-1 + NSet * (cAve-1 + NPcAve * (cMeas-1 + NMeas* (cIda-1 +...
                        NIda * (cIdb-1 + NIdc * (cIdd-1 + NIdd * (NIde-1)))))))))))));
       
            tempPhasCor   = temp(1:NPcCol,:);
            PcData(:,cPcIndex) =  PcData(:,cPcIndex) + tempPhasCor(:);
    
        end
        
       
        % read the refernce data 
        if (mask.MDH_PATREFSCAN || mask.MDH_PATREFANDIMASCAN) && ~arg_imaScanOnly
            
            cAve       = min(cAve ,NAveAlloc);
            cMeas      = min(cMeas,NMeasAlloc);
            cSeg       = min(cSeg ,NSegAlloc);
            
            cIndex = 1 +  (cLine - FirstRefLine  + NRefLines * ( cPart - FirstRefPart + NRefPart * (cSli-1 + NSli * (cEco-1 +...
                NEco * (cPhs-1 + NPhs * (cSeg-1 + NSegAlloc * (cSet-1 + NSet * (cAve-1 + NAveAlloc * (cMeas-1 + NMeasAlloc* (cIda-1 +...
                NIda * (cIdb-1 + NIdc * (cIdd-1 + NIdd * (NIde-1)))))))))))));
        
            
            tempRef           = temp(1:NRefCol,:);
            size(tempRef)
            RefData(:,cIndex) = RefData(:,cIndex) + tempRef(:);
            
            % if this line is an extra reference scan we don't want the
            % line in the imaging data
            if (RefScanMode == 4)
               continue
            end
        end
        
        
        % read the imaging data 
        if  (mask.MDH_IMASCAN && ~arg_refScanOnly)

            cAve       = min(cAve ,NAveAlloc);
            cMeas      = min(cMeas,NMeasAlloc);
            cSeg       = min(cSeg ,NSegAlloc);
             
             
            cIndex = 1 +  (cLine + (ImaMinLine-1) -  1 + NImaLines * ( cPart +(ImaMinPart-1) - 1  + NImaPart * (cSli-1 + NSli * (cEco-1 +...
                        NEco * (cPhs-1 + NPhs * (cSeg-1 + NSegAlloc * (cSet-1 + NSet * (cAve-1 + NAveAlloc * (cMeas-1 + NMeasAlloc* (cIda-1 +...
                        NIda * (cIdb-1 + NIdc * (cIdd-1 + NIdd * (NIde-1)))))))))))));
                 
            
            % exclude the integrated ACS data if the exclACS flag is set 
            if arg_exclACS
                 if (mask.MDH_PATREFSCAN && ~mask.MDH_PATREFANDIMASCAN)
                     continue
                end
            end
                      
            tempIma(ImaMinCol:ImaMaxCol,:) = temp;
          
            %ImaData(:,cIndex) = ImaData(:,cIndex) + tempIma(:);
            
            ImaData(:,cIndex) = tempIma(:);
            
            
        end
        
               
              
        % Display the Progress
        if (cPos/fileSize*100 > percentFinished + 1)
            percentFinished = floor(cPos/fileSize*100);
            elapsed_time  = toc;
            time_left     = (fileSize/cPos-1) * elapsed_time;

            if ~exist('progress_str','var')
                prevLength = 0;
            else
                prevLength = numel(progress_str);
            end

            progress_str = sprintf('%3.0f %% read in %3.0f s, at %3.1f MB/s; estimated time left: %3.0f s \n',...
            percentFinished,elapsed_time, cPos/1024^2/elapsed_time,time_left);

            fprintf([repmat('\b',1,prevLength) '%s'],progress_str);
        end
        

    end % while

  
    
        
    if isfield(header,'ImaScan') && ~arg_refScanOnly
        ImaData = reshape(ImaData, ImaSize);
        % move chan from 2nd to 4th position
        % applies tukey filter to the data (WIP fxbreuer)
        if arg_filter
            fprintf('Applying Tukey filter ... \n');
            % Read is 1st dimension
            filterCol = tukeywin(size(ImaMinCol:ImaMaxCol,2));
            ImaData(ImaMinCol:ImaMaxCol,:,:,:,:,:,:,:,:,:,:,:,:,:,:,:) = bsxfun(@times,ImaData(ImaMinCol:ImaMaxCol,:,:,:,:,:,:,:,:,:,:,:,:,:,:,:),filterCol);
            % Phase is 3rd dimension
            filterLine = reshape(tukeywin(size(ImaMinLine:ImaMaxLine,2)),[1 1 size(ImaMinLine:ImaMaxLine,2)]);
            ImaData(:,:,ImaMinLine:ImaMaxLine,:,:,:,:,:,:,:,:,:,:,:,:,:) = bsxfun(@times,ImaData(:,:,ImaMinLine:ImaMaxLine,:,:,:,:,:,:,:,:,:,:,:,:,:),filterLine);
            % Partition is 4th dimension
            filterPart = reshape(tukeywin(size(ImaMinPart:ImaMaxPart,2)),[1 1 1 size(ImaMinPart:ImaMaxPart,2)]);
            ImaData(:,:,:,ImaMinPart:ImaMaxPart,:,:,:,:,:,:,:,:,:,:,:,:) = bsxfun(@times,ImaData(:,:,:,ImaMinPart:ImaMaxPart,:,:,:,:,:,:,:,:,:,:,:,:),filterPart);
            
        end
        
        % move chan from 2nd to 4th position       
        ImaDataTmp = permute(ImaData,[1 3 4 2 5:ndims(ImaData)]);
        ImaData = ImaDataTmp;
    end

    if isfield(header,'RefScan') && ~arg_imaScanOnly
        RefData = reshape(RefData, RefSize);
        % move chan from 2nd to 4th position
        RefData = permute(RefData,[1 3 4 2 5:ndims(RefData)]);
    end

    if isfield(header,'NoiseScan')
        NoiseData = reshape(NoiseData, NoiseSize);
        % move chan from 2nd to 4th position
        NoiseData = permute(NoiseData,[1 3 4 2 5:ndims(NoiseData)]);
    end
    
    if isfield(header,'PhasCorScan')
        PcData = reshape(PcData, PcSize);
        % move chan from 2nd to 4th position
        PcData = permute(PcData,[1 3 4 2 5:ndims(PcData)]);
    end
   
    if arg_sqz
        if isfield(header,'ImaScan')
            ImaData   = squeeze(ImaData);
        elseif isfield(header,'RefScan')
            RefData   = squeeze(RefData);
        elseif isfield(header,'NoiseScan')
            NoiseData = squeeze(NoiseData);
        elseif isfield(header,'PhasCorScan')
            PcData  = squeeze(PcData);
        end
    end
    
    
    % output is struct   
    data.ImaData    = ImaData;
    data.RefData    = RefData;
    data.NoiseData  = NoiseData;
    data.PcData     = PcData;
    data.header     = header;
    data.arg        = arg;
    
end





%%% The following functions have all been inlined for speed reasons, so
%%% they are not used anymore in the code. You can remove them if you want
%%% to save a few bytes on your hard drive ;-).
%%% Unfortunately, inlining reduces readability. However, the speed gains are
%%% significant enough for this to make sense.

% readScanHeader:
%   reads scan header according to pkg/MrServers/MrMeasSrv/SeqIF/MDH/mdh.h
function header = readScanHeader(fid)

%     typedef struct sScanHeader {
%       PACKED_MEMBER( uint32_t,     ulFlagsAndDMALength           );                 //  0: ( 4) bit  0..24: DMA length [bytes]
%                                                                                     //          bit     25: pack bit
%                                                                                     //          bit 26..31: pci_rx enable flags
    header.ulFlagsAndDMALength        = fread(fid, 1, 'uint32');
%       PACKED_MEMBER( int32_t,      lMeasUID                      );                 //  4: ( 4) measurement user ID
    header.lMeasUID                   = fread(fid, 1, 'int32');
%       PACKED_MEMBER( uint32_t,     ulScanCounter                 );                 //  8: ( 4) scan counter [1...]
    header.ulScanCounter              = fread(fid, 1, 'uint32');
%       PACKED_MEMBER( uint32_t,     ulTimeStamp                   );                 // 12: ( 4) time stamp [2.5 ms ticks since 00:00]
    header.ulTimeStamp                = fread(fid, 1, 'uint32');
%       PACKED_MEMBER( uint32_t,     ulPMUTimeStamp                );                 // 16: ( 4) PMU time stamp [2.5 ms ticks since last trigger]
    header.ulPMUTimeStamp             = fread(fid, 1, 'uint32');
%       PACKED_MEMBER( uint16_t,     ushSystemType                 );                 // 20: ( 2) System type (todo: values?? ####)
    header.ushSystemType              = fread(fid, 1, 'uint16');
%       PACKED_MEMBER( uint16_t,     ulPTABPosDelay                );                 // 22: ( 2) PTAb delay ??? TODO: How do we handle this ####
    header.ulPTABPosDelay             = fread(fid, 1, 'uint16');
%       PACKED_MEMBER( int32_t,	   lPTABPosX                       );                 // 24: ( 4) absolute PTAB position in [0.1 mm]
    header.lPTABPosX                  = fread(fid, 1, 'int32');
%       PACKED_MEMBER( int32_t,	   lPTABPosY                       );                 // 28: ( 4) absolute PTAB position in [0.1 mm]
    header.lPTABPosY                  = fread(fid, 1, 'int32');
%       PACKED_MEMBER( int32_t,	   lPTABPosZ                       );                 // 32: ( 4) absolute PTAB position in [0.1 mm]
    header.lPTABPosZ                  = fread(fid, 1, 'int32');
%       PACKED_MEMBER( uint32_t,	   ulReserved1                 );                 // 36: ( 4) reserved for future hardware signals
    header.ulReserved1                = fread(fid, 1, 'uint32');
%       PACKED_MEMBER( uint32_t,     aulEvalInfoMask[MDH_NUMBEROFEVALINFOMASK]);      // 40: ( 8) evaluation info mask field
    header.aulEvalInfoMask            = fread(fid, [1 2],  'uint32');
%       PACKED_MEMBER( uint16_t,     ushSamplesInScan              );                 // 48: ( 2) # of samples acquired in scan
    header.ushSamplesInScan           = fread(fid, 1, 'uint16');
%       PACKED_MEMBER( uint16_t,     ushUsedChannels               );                 // 50: ( 2) # of channels used in scan
    header.ushUsedChannels            = fread(fid, 1, 'uint16');
%       PACKED_MEMBER( sLoopCounter, sLC                           );                 // 52: (28) loop counters
    header.sLC                        = fread(fid, [1 14],  'ushort');
%       PACKED_MEMBER( sCutOffData,  sCutOff                       );                 // 80: ( 4) cut-off values
    header.sCutOff                    = fread(fid, [1 2],  'ushort');
%       PACKED_MEMBER( uint16_t,     ushKSpaceCentreColumn         );                 // 84: ( 2) centre of echo
    header.ushKSpaceCentreColumn      = fread(fid, 1, 'uint16');
%       PACKED_MEMBER( uint16_t,     ushCoilSelect                 );                 // 86: ( 2) Bit 0..3: CoilSelect
    header.ushCoilSelect              = fread(fid, 1, 'uint16');
%       PACKED_MEMBER( float,        fReadOutOffcentre             );                 // 88: ( 4) ReadOut offcenter value
    header.fReadOutOffcentre          = fread(fid, 1, 'float');
%       PACKED_MEMBER( uint32_t,     ulTimeSinceLastRF             );                 // 92: ( 4) Sequence time stamp since last RF pulse
    header.ulTimeSinceLastRF          = fread(fid, 1, 'uint32');
%       PACKED_MEMBER( uint16_t,     ushKSpaceCentreLineNo         );                 // 96: ( 2) number of K-space centre line
    header.ushKSpaceCentreLineNo      = fread(fid, 1, 'uint16');
%       PACKED_MEMBER( uint16_t,     ushKSpaceCentrePartitionNo    );                 // 98: ( 2) number of K-space centre partition
    header.ushKSpaceCentrePartitionNo = fread(fid, 1, 'uint16');
%       PACKED_MEMBER( sSliceData,   sSD                           );                 // 100:(28) Slice Data
    header.sSD                        = fread(fid, [1 7],  'float'); 
%       PACKED_MEMBER( uint16_t,     aushIceProgramPara[MDH_NUMBEROFICEPROGRAMPARA] );// 128:(48) free parameter for IceProgram
    header.aushIceProgramPara         = fread(fid, [1 24], 'uint16');
%       PACKED_MEMBER( uint16_t,     aushReservedPara[MDH_RESERVEDHDRPARA] );         // 176:( 8) unused parameter (padding to next 192byte alignment )
%                                                                                     //          NOTE: These parameters MUST NOT be used by any application (for future use)
    header.aushReservedPara           = fread(fid, [1 4], 'uint16');
%       PACKED_MEMBER( uint16_t,     ushApplicationCounter         );                 // 184 ( 2)
    header.ushApplicationCounter      = fread(fid, 1, 'uint16');
%       PACKED_MEMBER( uint16_t,     ushApplicationMask            );                 // 186 ( 2)
    header.ushApplicationMask         = fread(fid, 1, 'uint16');
%       PACKED_MEMBER( uint32_t,     ulCRC                         );                 // 188:( 4) CRC 32 checksum
    header.ulCRC                      = fread(fid, 1, 'uint32');
%     } sScanHeader;                                                                  // total length: 6 x 32 Byte (192 Byte)

end


% readChannelHeader:
%   reads channel header according to pkg/MrServers/MrMeasSrv/SeqIF/MDH/mdh.h
function header = readChannelHeader(fid)

% typedef struct sChannelHeader
% {
%   PACKED_MEMBER( uint32_t,     ulTypeAndChannelLength        );    // 0: (4) bit  0.. 7: type (0x02 => ChannelHeader)
%                                                                    //        bit  8..31: channel length (header+data) in byte
%                                                                    //        type   := ulTypeAndChannelLength & 0x000000FF
%                                                                    //        length := ulTypeAndChannelLength >> 8
    header.ulTypeAndChannelLength = fread(fid, 1, 'uint32');
%   PACKED_MEMBER( int32_t,      lMeasUID                      );    // 4: (4) measurement user ID
    header.lMeasUID               = fread(fid, 1, 'uint32');
%   PACKED_MEMBER( uint32_t,     ulScanCounter                 );    // 8: (4) scan counter [1...]
    header.ulScanCounter          = fread(fid, 1, 'uint32');
%   PACKED_MEMBER( uint32_t,     ulReserved1                   );    // 12:(4) reserved
    header.ulReserved1            = fread(fid, 1, 'uint32');
%   PACKED_MEMBER( uint32_t,     ulSequenceTime                );    // 16:(4) Sequence readout starting time bit 31..9 time in [10us]
    header.ulSequenceTime         = fread(fid, 1, 'uint32');
%                                                                    //                                       bit  8..0 time in [25ns]
%   PACKED_MEMBER( uint32_t,     ulUnused2                     );    // 20:(4) unused
    header.ulUnused2              = fread(fid, 1, 'uint32');
%   PACKED_MEMBER( uint16_t,     ulChannelId                   );    // 24:(4) unused
    header.ulChannelId            = fread(fid, 1, 'uint16');
%   PACKED_MEMBER( uint16_t,     ulUnused3                     );    // 26:(2) unused
    header.ulUnused3              = fread(fid, 1, 'uint16');
%   PACKED_MEMBER( uint32_t,     ulCRC                         );    // 28:(4) CRC32 checksum of channel header
    header.ulCRC                  = fread(fid, 1, 'uint32');
% } sChannelHeader;                                                  // total length:  32 byte

end


% evalInfoMask:
%   evaluates infoMask
function mask = evalInfoMask(infoMask)

    %%%% PreScans
    mask.MDH_RTFEEDBACK         = min(bitand(infoMask(1), 2^1),1);
    mask.MDH_HPFEEDBACK         = min(bitand(infoMask(1), 2^2),1);
    mask.MDH_REFPHASESTABSCAN   = min(bitand(infoMask(1), 2^14),1);
    mask.MDH_PHASESTABSCAN      = min(bitand(infoMask(1), 2^15),1);
    mask.MDH_PHASCOR            = min(bitand(infoMask(1), 2^21),1);
    mask.MDH_NOISEADJSCAN       = min(bitand(infoMask(1), 2^25),1);

    %%%% ImageScans
    mask.MDH_PATREFSCAN         = min(bitand(infoMask(1), 2^22),1);
    mask.MDH_PATREFANDIMASCAN   = min(bitand(infoMask(1), 2^23),1);

    %%%% flags
    mask.MDH_REFLECT            = min(bitand(infoMask(1), 2^24),1);
    mask.MDH_RAWDATACORRECTION  = min(bitand(infoMask(1), 2^10),1);
    mask.MDH_SIGNREV            = min(bitand(infoMask(1), 2^17),1);
            
    %%%% ACQ END FLAG
    mask.MDH_ACQEND             = min(bitand(infoMask(1), 2^0),1);

    mask.MDH_IMASCAN            = 1;

    % Exclude Pre and Correction Scans
    if (mask.MDH_ACQEND || mask.MDH_RTFEEDBACK || mask.MDH_HPFEEDBACK || mask.MDH_REFPHASESTABSCAN || mask.MDH_PHASESTABSCAN || mask.MDH_PHASCOR || mask.MDH_NOISEADJSCAN)
        mask.MDH_IMASCAN = 0; 
    end
end
