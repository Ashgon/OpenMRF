function header = readVD_header(filename)

%  Reads Siemens Avanto .dat raw data from VB13, VB15 and VB17
%  Data file contains an header and a data block.
%  Raw data is oversampled!
%
%  REQUIRES: readVD11Header.m
%
%  Philipp Ehses 11.02.07, updated for VB15 1.April 09
%  Daniel Weber  27.08.09, updated for VB17
%  Philipp Ehses 04.09.09, added direct averaging mode
%  Philipp Ehses 10.01.10, added fastRead + progress output
%  Felix Breuer  31.03.11, added support for noise & ref scans
%  Martin Blaimer 17.02.15, removed everything except header output
%
% Output:
%
% header:       header information (TRs, TEs,...)
%
%
% Input parameters:
%      
% filename:      Entweder kompletter Dateiname mit Pfad, oder nur eine Nummer, die dann f???r meas_MIDxxxx_*.dat steht
% 
%
%

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Option, die MeasNumber statt des Dateinamens zu uebergeben:
    if ischar(filename)
        if  ~strcmpi(filename(end-3:end),'.dat');
            filename=[filename '.dat'];   %% adds filetype ending to file
        end
    else % filename not a string, so assume that it is the MeasNumber (shortcut, instead of Avanto_fullfile)
        
        num = filename;
               
        
        try
            filename = ls(['meas_MID*' num2str(num) '_*FID*.dat'])% tbenkert: modification to ignore zeros in front of real MID number
        catch ME
            filename = ls(['meas_MID' sprintf('%05d',num) '_*.dat'])
        end
        
        
        if isunix
            str = strfind(filename,'.dat');
            filename=[filename(1:str-1) '.dat']; % crops line break
        end
    end
    
    
    
    tic;
    fid = fopen(filename,'r','l','US-ASCII'); % US-ASCII necessary for UNIX based systems
    fseek(fid,0,'eof');
    fileSize = ftell(fid);
    
    fseek(fid,4,'bof');
    NMeas = fread(fid,1,'uint32'); % number of measurements in file, only one supported for now
    fseek(fid,16,'bof');
    % measOffset: points to beginning of header, usually at 10240 bytes
    measOffset = fread(fid,1,'uint64');
    measLength = fread(fid,1,'uint64');
    fseek(fid,measOffset,'bof');
    hdrLength = fread(fid,1,'uint32');
    
    datStart  = measOffset + hdrLength;
    
    % reads protocol header information
    [header headerascii] = readVD11Header(fid);
    
end

%%% The following functions have all been inlined for speed reasons, so
%%% they are not used anymore in the code. You can remove them if you want
%%% to save a few bytes on your hard drive ;-).
%%% Unfortunately, inlining reduces readability. However, the speed gains are
%%% significant enough for this to make sense.

% readScanHeader:
%   reads scan header according to pkg/MrServers/MrMeasSrv/SeqIF/MDH/mdh.h
function header = readScanHeader(fid)

%     typedef struct sScanHeader {
%       PACKED_MEMBER( uint32_t,     ulFlagsAndDMALength           );                 //  0: ( 4) bit  0..24: DMA length [bytes]
%                                                                                     //          bit     25: pack bit
%                                                                                     //          bit 26..31: pci_rx enable flags
    header.ulFlagsAndDMALength        = fread(fid, 1, 'uint32');
%       PACKED_MEMBER( int32_t,      lMeasUID                      );                 //  4: ( 4) measurement user ID
    header.lMeasUID                   = fread(fid, 1, 'int32');
%       PACKED_MEMBER( uint32_t,     ulScanCounter                 );                 //  8: ( 4) scan counter [1...]
    header.ulScanCounter              = fread(fid, 1, 'uint32');
%       PACKED_MEMBER( uint32_t,     ulTimeStamp                   );                 // 12: ( 4) time stamp [2.5 ms ticks since 00:00]
    header.ulTimeStamp                = fread(fid, 1, 'uint32');
%       PACKED_MEMBER( uint32_t,     ulPMUTimeStamp                );                 // 16: ( 4) PMU time stamp [2.5 ms ticks since last trigger]
    header.ulPMUTimeStamp             = fread(fid, 1, 'uint32');
%       PACKED_MEMBER( uint16_t,     ushSystemType                 );                 // 20: ( 2) System type (todo: values?? ####)
    header.ushSystemType              = fread(fid, 1, 'uint16');
%       PACKED_MEMBER( uint16_t,     ulPTABPosDelay                );                 // 22: ( 2) PTAb delay ??? TODO: How do we handle this ####
    header.ulPTABPosDelay             = fread(fid, 1, 'uint16');
%       PACKED_MEMBER( int32_t,	   lPTABPosX                       );                 // 24: ( 4) absolute PTAB position in [0.1 mm]
    header.lPTABPosX                  = fread(fid, 1, 'int32');
%       PACKED_MEMBER( int32_t,	   lPTABPosY                       );                 // 28: ( 4) absolute PTAB position in [0.1 mm]
    header.lPTABPosY                  = fread(fid, 1, 'int32');
%       PACKED_MEMBER( int32_t,	   lPTABPosZ                       );                 // 32: ( 4) absolute PTAB position in [0.1 mm]
    header.lPTABPosZ                  = fread(fid, 1, 'int32');
%       PACKED_MEMBER( uint32_t,	   ulReserved1                 );                 // 36: ( 4) reserved for future hardware signals
    header.ulReserved1                = fread(fid, 1, 'uint32');
%       PACKED_MEMBER( uint32_t,     aulEvalInfoMask[MDH_NUMBEROFEVALINFOMASK]);      // 40: ( 8) evaluation info mask field
    header.aulEvalInfoMask            = fread(fid, [1 2],  'uint32');
%       PACKED_MEMBER( uint16_t,     ushSamplesInScan              );                 // 48: ( 2) # of samples acquired in scan
    header.ushSamplesInScan           = fread(fid, 1, 'uint16');
%       PACKED_MEMBER( uint16_t,     ushUsedChannels               );                 // 50: ( 2) # of channels used in scan
    header.ushUsedChannels            = fread(fid, 1, 'uint16');
%       PACKED_MEMBER( sLoopCounter, sLC                           );                 // 52: (28) loop counters
    header.sLC                        = fread(fid, [1 14],  'ushort');
%       PACKED_MEMBER( sCutOffData,  sCutOff                       );                 // 80: ( 4) cut-off values
    header.sCutOff                    = fread(fid, [1 2],  'ushort');
%       PACKED_MEMBER( uint16_t,     ushKSpaceCentreColumn         );                 // 84: ( 2) centre of echo
    header.ushKSpaceCentreColumn      = fread(fid, 1, 'uint16');
%       PACKED_MEMBER( uint16_t,     ushCoilSelect                 );                 // 86: ( 2) Bit 0..3: CoilSelect
    header.ushCoilSelect              = fread(fid, 1, 'uint16');
%       PACKED_MEMBER( float,        fReadOutOffcentre             );                 // 88: ( 4) ReadOut offcenter value
    header.fReadOutOffcentre          = fread(fid, 1, 'float');
%       PACKED_MEMBER( uint32_t,     ulTimeSinceLastRF             );                 // 92: ( 4) Sequence time stamp since last RF pulse
    header.ulTimeSinceLastRF          = fread(fid, 1, 'uint32');
%       PACKED_MEMBER( uint16_t,     ushKSpaceCentreLineNo         );                 // 96: ( 2) number of K-space centre line
    header.ushKSpaceCentreLineNo      = fread(fid, 1, 'uint16');
%       PACKED_MEMBER( uint16_t,     ushKSpaceCentrePartitionNo    );                 // 98: ( 2) number of K-space centre partition
    header.ushKSpaceCentrePartitionNo = fread(fid, 1, 'uint16');
%       PACKED_MEMBER( sSliceData,   sSD                           );                 // 100:(28) Slice Data
    header.sSD                        = fread(fid, [1 7],  'float'); 
%       PACKED_MEMBER( uint16_t,     aushIceProgramPara[MDH_NUMBEROFICEPROGRAMPARA] );// 128:(48) free parameter for IceProgram
    header.aushIceProgramPara         = fread(fid, [1 24], 'uint16');
%       PACKED_MEMBER( uint16_t,     aushReservedPara[MDH_RESERVEDHDRPARA] );         // 176:( 8) unused parameter (padding to next 192byte alignment )
%                                                                                     //          NOTE: These parameters MUST NOT be used by any application (for future use)
    header.aushReservedPara           = fread(fid, [1 4], 'uint16');
%       PACKED_MEMBER( uint16_t,     ushApplicationCounter         );                 // 184 ( 2)
    header.ushApplicationCounter      = fread(fid, 1, 'uint16');
%       PACKED_MEMBER( uint16_t,     ushApplicationMask            );                 // 186 ( 2)
    header.ushApplicationMask         = fread(fid, 1, 'uint16');
%       PACKED_MEMBER( uint32_t,     ulCRC                         );                 // 188:( 4) CRC 32 checksum
    header.ulCRC                      = fread(fid, 1, 'uint32');
%     } sScanHeader;                                                                  // total length: 6 x 32 Byte (192 Byte)

end


% readChannelHeader:
%   reads channel header according to pkg/MrServers/MrMeasSrv/SeqIF/MDH/mdh.h
function header = readChannelHeader(fid)

% typedef struct sChannelHeader
% {
%   PACKED_MEMBER( uint32_t,     ulTypeAndChannelLength        );    // 0: (4) bit  0.. 7: type (0x02 => ChannelHeader)
%                                                                    //        bit  8..31: channel length (header+data) in byte
%                                                                    //        type   := ulTypeAndChannelLength & 0x000000FF
%                                                                    //        length := ulTypeAndChannelLength >> 8
    header.ulTypeAndChannelLength = fread(fid, 1, 'uint32');
%   PACKED_MEMBER( int32_t,      lMeasUID                      );    // 4: (4) measurement user ID
    header.lMeasUID               = fread(fid, 1, 'uint32');
%   PACKED_MEMBER( uint32_t,     ulScanCounter                 );    // 8: (4) scan counter [1...]
    header.ulScanCounter          = fread(fid, 1, 'uint32');
%   PACKED_MEMBER( uint32_t,     ulReserved1                   );    // 12:(4) reserved
    header.ulReserved1            = fread(fid, 1, 'uint32');
%   PACKED_MEMBER( uint32_t,     ulSequenceTime                );    // 16:(4) Sequence readout starting time bit 31..9 time in [10us]
    header.ulSequenceTime         = fread(fid, 1, 'uint32');
%                                                                    //                                       bit  8..0 time in [25ns]
%   PACKED_MEMBER( uint32_t,     ulUnused2                     );    // 20:(4) unused
    header.ulUnused2              = fread(fid, 1, 'uint32');
%   PACKED_MEMBER( uint16_t,     ulChannelId                   );    // 24:(4) unused
    header.ulChannelId            = fread(fid, 1, 'uint16');
%   PACKED_MEMBER( uint16_t,     ulUnused3                     );    // 26:(2) unused
    header.ulUnused3              = fread(fid, 1, 'uint16');
%   PACKED_MEMBER( uint32_t,     ulCRC                         );    // 28:(4) CRC32 checksum of channel header
    header.ulCRC                  = fread(fid, 1, 'uint32');
% } sChannelHeader;                                                  // total length:  32 byte

end


% evalInfoMask:
%   evaluates infoMask
function mask = evalInfoMask(infoMask)

    %%%% PreScans
    mask.MDH_RTFEEDBACK         = min(bitand(infoMask(1), 2^1),1);
    mask.MDH_HPFEEDBACK         = min(bitand(infoMask(1), 2^2),1);
    mask.MDH_REFPHASESTABSCAN   = min(bitand(infoMask(1), 2^14),1);
    mask.MDH_PHASESTABSCAN      = min(bitand(infoMask(1), 2^15),1);
    mask.MDH_PHASCOR            = min(bitand(infoMask(1), 2^21),1);
    mask.MDH_NOISEADJSCAN       = min(bitand(infoMask(1), 2^25),1);

    %%%% ImageScans
    mask.MDH_PATREFSCAN         = min(bitand(infoMask(1), 2^22),1);
    mask.MDH_PATREFANDIMASCAN   = min(bitand(infoMask(1), 2^23),1);

    %%%% flags
    mask.MDH_REFLECT            = min(bitand(infoMask(1), 2^24),1);
    mask.MDH_RAWDATACORRECTION  = min(bitand(infoMask(1), 2^10),1);
    mask.MDH_SIGNREV            = min(bitand(infoMask(1), 2^17),1);
            
    %%%% ACQ END FLAG
    mask.MDH_ACQEND             = min(bitand(infoMask(1), 2^0),1);

    mask.MDH_IMASCAN            = 1;

    % Exclude Pre and Correction Scans
    if (mask.MDH_ACQEND || mask.MDH_RTFEEDBACK || mask.MDH_HPFEEDBACK || mask.MDH_REFPHASESTABSCAN || mask.MDH_PHASESTABSCAN || mask.MDH_PHASCOR || mask.MDH_NOISEADJSCAN)
        mask.MDH_IMASCAN = 0; 
    end
end
