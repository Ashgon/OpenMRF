function a = diff(a)

a.data = diff(a.data);

