function res = END(a,K,N)

res = length(a);

