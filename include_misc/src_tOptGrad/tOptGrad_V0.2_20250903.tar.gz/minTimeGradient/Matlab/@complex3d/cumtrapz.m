function a = cumtrapz(a);

a.data = cumtrapz(a.data);

