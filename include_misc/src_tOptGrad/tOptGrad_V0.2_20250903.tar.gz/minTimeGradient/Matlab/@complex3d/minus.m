function res = minus(a,b)

data = a.data - b.data;

res = complex3d(data);

