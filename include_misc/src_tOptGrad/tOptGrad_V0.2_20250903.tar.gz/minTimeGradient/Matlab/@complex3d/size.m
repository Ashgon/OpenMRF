function res = size(a)

res = [length(a), 1];

